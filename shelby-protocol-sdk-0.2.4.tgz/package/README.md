# @shelby-protocol/sdk

A TypeScript SDK providing core encoding and decoding utilities for both Node.js and browser environments.

## Installation

```bash
# Installing the shelby sdk
pnpm install @shelby-protocol/sdk @aptos-labs/ts-sdk
```

## Usage

Depending on your runtime environment, import from one of the following entrypoints:

### Node.js

```ts
import { ShelbyNodeClient } from '@shelby-protocol/sdk/node';

// Your code here...
```

### Browser

```ts
import { ShelbyBlob } from '@shelby-protocol/sdk/browser';

// Your code here...
```

### Working with Erasure Coding Providers

The SDK supports two patterns for managing erasure coding providers:

#### Default Pattern (Recommended for most users)

```ts
import { ShelbyClient } from '@shelby-protocol/sdk';

// Provider is created internally on first use
const client = new ShelbyClient(config);

// The client will automatically create and manage the provider
await client.upload({
  blobData: data,
  signer: account,
  blobName: "example.txt",
  expirationMicros: Date.now() * 1000 + 3600_000_000,
});
```

#### Shared Provider Pattern (For advanced use cases)

When working with multiple clients (e.g., different networks), you can share a single provider instance:

```ts
import { ShelbyClient, ClayErasureCodingProvider } from '@shelby-protocol/sdk';

// Create a single provider instance
const provider = await ClayErasureCodingProvider.create();

// Share it across multiple clients
const mainnetClient = new ShelbyClient(mainnetConfig, provider);
const devnetClient = new ShelbyClient(devnetConfig, provider);
const testnetClient = new ShelbyClient(testnetConfig, provider);

// All clients use the same provider instance
await mainnetClient.upload({ /* ... */ });
await devnetClient.upload({ /* ... */ });
```

## Peer Dependencies

- `@aptos-labs/ts-sdk`

## Scripts

```bash
npm run build      # compile TypeScript to dist/
npm run test       # watch mode with Vitest
npm run test:once  # single-run tests
npm run lint       # run biome diagnostics
npm run fmt        # auto-format with biome
```

---

> Please import the entrypoint that matches your environment (`/node`, `/browser`, or the root) to ensure you get the correct implementation and avoid missing-module errors.
